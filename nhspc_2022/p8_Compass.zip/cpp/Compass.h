void set_col(int x, int y, int len, int val);
void set_row(int x, int y, int len, int val);
void not_col(int x, int y, int xout, int yout, int len);
void not_row(int x, int y, int xout, int yout, int len);
void and_col(int x1, int y1, int x2, int y2, int xout, int yout, int len);
void and_row(int x1, int y1, int x2, int y2, int xout, int yout, int len);
void or_col(int x1, int y1, int x2, int y2, int xout, int yout, int len);
void or_row(int x1, int y1, int x2, int y2, int xout, int yout, int len);
void xor_col(int x1, int y1, int x2, int y2, int xout, int yout, int len);
void xor_row(int x1, int y1, int x2, int y2, int xout, int yout, int len);
void debug(int x, int y);

void draw_circle();
